import React, { useEffect, useState } from 'react';

interface NotificationProps {
  message: string;
  onClose: () => void;
}

const Notification: React.FC<NotificationProps> = ({ message, onClose }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true); // Trigger fade-in animation
    const timer = setTimeout(() => {
      setVisible(false); // Trigger fade-out animation
      setTimeout(onClose, 500); // Wait for animation to finish before calling onClose
    }, 3000);

    return () => clearTimeout(timer);
  }, [message, onClose]);

  return (
    <div 
      className={`fixed top-5 left-1/2 -translate-x-1/2 bg-green-600 text-white px-6 py-3 rounded-full shadow-lg transition-all duration-500 ease-in-out z-50 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'}`}
    >
      <p className="font-semibold">{message}</p>
    </div>
  );
};

export default Notification;

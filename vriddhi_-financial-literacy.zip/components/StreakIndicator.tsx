import React from 'react';
import { FireIcon } from './icons/Icons';

interface StreakIndicatorProps {
  streak: number;
}

const StreakIndicator: React.FC<StreakIndicatorProps> = ({ streak }) => {
  if (streak === 0) {
    return null;
  }

  return (
    <div className="absolute top-4 right-4 bg-black bg-opacity-50 rounded-full px-3 py-1.5 flex items-center space-x-2 text-white shadow-lg z-10">
      <FireIcon className="h-6 w-6 text-orange-400" />
      <span className="font-bold text-lg">{streak}</span>
    </div>
  );
};

export default StreakIndicator;

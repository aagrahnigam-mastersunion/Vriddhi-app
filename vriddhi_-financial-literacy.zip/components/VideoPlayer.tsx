import React, { useRef, useState, useEffect } from 'react';
import { Video } from '../types';
import { HeartIcon, ShareIcon, PlayIcon, CheckCircleIcon, SolidHeartIcon } from './icons/Icons';

interface VideoPlayerProps {
  video: Video;
  onLike: (videoId: number) => void;
  onWatch: (videoId: number) => void;
  onShare: (videoId: number) => void;
  isLiked: boolean;
  isActive: boolean;
  isDownloaded: boolean;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ video, onLike, onWatch, onShare, isLiked, isActive, isDownloaded }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const watchTimeoutRef = useRef<number | null>(null);

  useEffect(() => {
    if (isActive) {
      videoRef.current?.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    } else {
      videoRef.current?.pause();
      setIsPlaying(false);
    }
  }, [isActive]);
  
  const handlePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  useEffect(() => {
    const videoElement = videoRef.current;
    
    const handleTimeUpdate = () => {
        if (videoElement && videoElement.duration > 0) {
            const watchedPercentage = (videoElement.currentTime / videoElement.duration) * 100;
            if (watchedPercentage > 80 && !watchTimeoutRef.current) {
                onWatch(video.id);
            }
        }
    };

    if (videoElement) {
        videoElement.addEventListener('timeupdate', handleTimeUpdate);
    }

    return () => {
        if (videoElement) {
            videoElement.removeEventListener('timeupdate', handleTimeUpdate);
        }
        if (watchTimeoutRef.current) {
            clearTimeout(watchTimeoutRef.current);
        }
    };
  }, [video.id, onWatch]);

  return (
    <div className="relative h-full w-full bg-black snap-start" onClick={handlePlayPause}>
      <video
        ref={videoRef}
        src={video.url}
        loop
        className="w-full h-full object-cover"
        playsInline
      />
      {!isPlaying && (
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-20">
            <PlayIcon className="h-20 w-20 text-white opacity-70" />
        </div>
      )}
      <div className="absolute bottom-0 left-0 right-0 p-4 text-white bg-gradient-to-t from-black/60 to-transparent">
        <div className="flex justify-between items-end">
          <div className="flex-1 pr-4">
            <div className="flex items-center space-x-2">
                <h3 className="font-bold text-lg">{video.author}</h3>
                {isDownloaded && <CheckCircleIcon className="h-5 w-5 text-green-400" title="Downloaded" />}
            </div>
            <p className="text-sm">{video.title}</p>
            <p className="text-xs text-gray-300 mt-1">{video.description}</p>
          </div>
          <div className="flex flex-col items-center space-y-4">
            <button onClick={(e) => { e.stopPropagation(); onLike(video.id); }} className="flex flex-col items-center">
              {isLiked ? <SolidHeartIcon className="h-8 w-8 text-red-500" /> : <HeartIcon className="h-8 w-8" />}
              <span className="text-xs">पसंद</span>
            </button>
            <button onClick={(e) => { e.stopPropagation(); onShare(video.id); }} className="flex flex-col items-center">
              <ShareIcon className="h-8 w-8" />
              <span className="text-xs">शेयर</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
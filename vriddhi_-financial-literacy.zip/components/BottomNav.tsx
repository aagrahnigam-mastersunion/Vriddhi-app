
import React from 'react';
import { Tab } from '../types';

interface BottomNavProps {
  tabs: { id: Tab; name: string; icon: React.FC<any> }[];
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ tabs, activeTab, setActiveTab }) => {
  return (
    <nav className="bg-gray-800 border-t border-gray-700">
      <div className="max-w-md mx-auto flex justify-around">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center justify-center w-full pt-2 pb-1 text-xs ${
              activeTab === tab.id ? 'text-amber-400' : 'text-gray-400'
            }`}
          >
            <tab.icon className="h-6 w-6 mb-1" />
            <span>{tab.name}</span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export default BottomNav;

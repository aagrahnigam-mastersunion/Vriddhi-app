import React, { useState } from 'react';
import { INDIA_STATES_DISTRICTS } from '../data/locations';

interface LoginScreenProps {
  onLogin: (name: string, district: string, state: string) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [state, setState] = useState('');
  const [district, setDistrict] = useState('');

  const states = Object.keys(INDIA_STATES_DISTRICTS);
  const districts = state ? INDIA_STATES_DISTRICTS[state as keyof typeof INDIA_STATES_DISTRICTS] : [];

  const handleStateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setState(e.target.value);
    setDistrict(''); // Reset district when state changes
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && district && state) {
      onLogin(name, district, state);
    } else {
      alert('कृपया सभी जानकारी भरें।');
    }
  };
  
  const formElementStyle = "shadow appearance-none border border-gray-600 rounded w-full py-3 px-4 bg-gray-800 text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-amber-500";

  return (
    <div className="h-screen w-screen flex flex-col justify-center items-center bg-gray-900 text-white p-4 max-w-md mx-auto">
        <div className="text-center mb-10">
            <h1 className="text-5xl font-bold text-amber-400">वृद्धि</h1>
            <p className="text-xl text-gray-300 mt-2">सीखें, खेलें, और कमाएं</p>
        </div>
        <form onSubmit={handleSubmit} className="w-full max-w-sm">
            <div className="mb-4">
                <label htmlFor="name" className="block text-gray-300 text-sm font-bold mb-2">आपका नाम</label>
                <input 
                    type="text" 
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={formElementStyle}
                    placeholder="जैसे - सुरेश कुमार"
                />
            </div>
             <div className="mb-4">
                <label htmlFor="state" className="block text-gray-300 text-sm font-bold mb-2">आपका राज्य</label>
                <select 
                    id="state"
                    value={state}
                    onChange={handleStateChange}
                    className={formElementStyle}
                >
                    <option value="" disabled>राज्य चुनें</option>
                    {states.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
            </div>
             <div className="mb-6">
                <label htmlFor="district" className="block text-gray-300 text-sm font-bold mb-2">आपका जिला</label>
                <select 
                    id="district"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className={formElementStyle}
                    disabled={!state}
                >
                    <option value="" disabled>{state ? 'जिला चुनें' : 'पहले राज्य चुनें'}</option>
                    {districts.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
            </div>
            <div className="flex items-center justify-center">
                <button 
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-600 text-black font-bold py-3 px-4 rounded-full focus:outline-none focus:shadow-outline text-lg"
                >
                    शुरू करें
                </button>
            </div>
        </form>
    </div>
  );
};

export default LoginScreen;



import React, { useState } from 'react';
import { Video } from '../types';
import { DownloadIcon, CheckCircleIcon, TrashIcon } from '../components/icons/Icons';

interface LibraryScreenProps {
  allVideos: Video[];
  likedVideos: Video[];
  downloadingVideos: Map<number, number>; // videoId -> progress %
  downloadedIds: Set<number>;
  videoSizes: Map<number, number>; // videoId -> size in bytes
  onDownload: (videoId: number) => void;
  onDelete: (videoId: number) => void;
}

type LibraryView = 'liked' | 'downloads';

const TOTAL_STORAGE_BYTES = 500 * 1024 * 1024; // 500 MB

const LibraryScreen: React.FC<LibraryScreenProps> = ({ allVideos, likedVideos, downloadingVideos, downloadedIds, videoSizes, onDownload, onDelete }) => {
  const [view, setView] = useState<LibraryView>('liked');

  const groupedAllVideos: { [topic: string]: Video[] } = allVideos.reduce((acc, video) => {
    (acc[video.topic] = acc[video.topic] || []).push(video);
    return acc;
  }, {} as { [topic: string]: Video[] });

  const groupedLikedVideos: { [topic: string]: Video[] } = likedVideos.reduce((acc, video) => {
    (acc[video.topic] = acc[video.topic] || []).push(video);
    return acc;
  }, {} as { [topic: string]: Video[] });
  
  const getTabStyle = (tabName: LibraryView) => {
    return view === tabName
        ? 'border-amber-400 text-amber-400'
        : 'border-transparent text-gray-400';
  };

  const renderVideoList = (groupedVideos: { [topic: string]: Video[] }) => {
      if (Object.keys(groupedVideos).length === 0) {
        return (
          <div className="flex flex-col items-center justify-center h-full text-gray-400 pt-16">
            <p>आपने अभी तक कोई वीडियो पसंद नहीं किया है।</p>
            <p className="text-sm">होम स्क्रीन पर ❤️ दबाकर वीडियो सेव करें।</p>
          </div>
        );
      }

      return Object.entries(groupedVideos).map(([topic, videos]) => (
          <div key={topic} className="mb-6">
            <h2 className="text-xl font-semibold border-b-2 border-amber-400 pb-2 mb-3">{topic}</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {videos.map(video => (
                <div key={video.id} className="bg-gray-800 rounded-lg overflow-hidden shadow-lg">
                  <video src={video.url} className="w-full h-24 object-cover" />
                  <div className="p-2">
                    <h3 className="text-sm font-semibold truncate">{video.title}</h3>
                    <p className="text-xs text-gray-400">{video.author}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
      ));
  };
  
  const renderDownloadsView = () => {
    // FIX: Explicitly type the accumulator `acc` and ensure `size` is handled as a number to prevent type errors during the arithmetic operation.
    const totalDownloadedSize = Array.from(videoSizes.values()).reduce((acc: number, size) => acc + (Number(size) || 0), 0);
    const usedPercentage = (totalDownloadedSize / TOTAL_STORAGE_BYTES) * 100;
    
    const formatBytes = (bytes: number, decimals = 2) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    return (
      <div>
        <div className="mb-6 bg-gray-800 rounded-lg p-4">
            <h3 className="text-lg font-semibold mb-2">स्टोरेज उपयोग</h3>
            <div className="w-full bg-gray-700 rounded-full h-2.5">
                <div className="bg-amber-500 h-2.5 rounded-full" style={{ width: `${usedPercentage}%` }}></div>
            </div>
            <p className="text-xs text-gray-400 mt-1 text-right">
                {formatBytes(totalDownloadedSize)} / {formatBytes(TOTAL_STORAGE_BYTES)}
            </p>
        </div>
        
        {Object.entries(groupedAllVideos).map(([topic, videos]) => {
            const moduleVideoIds = videos.map(v => v.id);
            // FIX: Explicitly type `id` as a number to prevent it from being inferred as `unknown` by TypeScript.
            const isAnyModuleVideoDownloading = moduleVideoIds.some((id: number) => downloadingVideos.has(id));
            const areAllVideosDownloaded = moduleVideoIds.every((id: number) => downloadedIds.has(id));
            
            const handleModuleDownload = () => {
                videos.forEach(video => {
                    if(!downloadedIds.has(video.id) && !downloadingVideos.has(video.id)) {
                        onDownload(video.id);
                    }
                });
            };

            return (
                <div key={topic} className="mb-6 bg-gray-800 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-semibold text-amber-400">{topic}</h2>
                        <button 
                          onClick={handleModuleDownload}
                          disabled={areAllVideosDownloaded || isAnyModuleVideoDownloading}
                          className="flex items-center space-x-2 bg-amber-500 text-black px-3 py-1 rounded-full text-sm font-semibold disabled:bg-gray-600 disabled:cursor-not-allowed">
                           {areAllVideosDownloaded ? <CheckCircleIcon className="h-4 w-4"/> : <DownloadIcon className="h-4 w-4" />}
                           <span>{areAllVideosDownloaded ? 'डाउनलोड हो गया' : 'सभी डाउनलोड करें'}</span>
                        </button>
                    </div>
                    <div className="space-y-3">
                        {videos.map(video => {
                            const isDownloading = downloadingVideos.has(video.id);
                            const downloadProgress = downloadingVideos.get(video.id) || 0;
                            const isDownloaded = downloadedIds.has(video.id);

                            return (
                                <div key={video.id} className="flex items-center justify-between bg-gray-700 p-2 rounded-md">
                                    <div className="flex-1 overflow-hidden pr-2">
                                        <p className="truncate text-sm font-medium">{video.title}</p>
                                        <p className="text-xs text-gray-400">{video.author}</p>
                                        {isDownloading && (
                                            <div className="w-full bg-gray-600 rounded-full h-1.5 mt-1">
                                                <div className="bg-green-500 h-1.5 rounded-full" style={{ width: `${downloadProgress}%` }}></div>
                                            </div>
                                        )}
                                    </div>
                                    <div className="w-10 flex items-center justify-center">
                                        {isDownloading ? (
                                            <span className="text-xs text-amber-400">{downloadProgress}%</span>
                                        ) : isDownloaded ? (
                                            <button onClick={() => onDelete(video.id)} title="Delete Download">
                                                <TrashIcon className="h-6 w-6 text-red-500 hover:text-red-400"/>
                                            </button>
                                        ) : (
                                            <button onClick={() => onDownload(video.id)} title="Download Video">
                                                <DownloadIcon className="h-6 w-6 text-gray-300 hover:text-white"/>
                                            </button>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            );
        })}
      </div>
    );
  };


  return (
    <div className="h-full bg-gray-900 text-white flex flex-col">
       <div className="p-4">
         <h1 className="text-2xl font-bold text-amber-400 mb-4">ज्ञान (Library)</h1>
          <div className="border-b border-gray-700">
            <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                <button onClick={() => setView('liked')} className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm ${getTabStyle('liked')}`}>
                    पसंदीदा
                </button>
                <button onClick={() => setView('downloads')} className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm ${getTabStyle('downloads')}`}>
                    ऑफ़लाइन / डाउनलोड
                </button>
            </nav>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {view === 'liked' ? renderVideoList(groupedLikedVideos) : renderDownloadsView()}
      </div>
    </div>
  );
};

export default LibraryScreen;
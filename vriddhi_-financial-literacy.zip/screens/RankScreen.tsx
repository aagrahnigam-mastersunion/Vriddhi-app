import React, { useState, useMemo } from 'react';
import { User, LeaderboardEntry } from '../types';
import { MOCK_ALL_USERS } from '../constants';

interface RankScreenProps {
  currentUser: User;
  currentUserSikka: number;
}

type FilterType = 'district' | 'state' | 'all';

// A type for the user data from constants, which doesn't have a rank yet
type MockUser = Omit<LeaderboardEntry, 'rank' | 'isCurrentUser'>;

const RankScreen: React.FC<RankScreenProps> = ({ currentUser, currentUserSikka }) => {
  const [filter, setFilter] = useState<FilterType>('district');

  const leaderboardData = useMemo(() => {
    let filteredUsers: MockUser[];

    switch (filter) {
      case 'district':
        filteredUsers = MOCK_ALL_USERS.filter(u => u.district === currentUser.district);
        break;
      case 'state':
        filteredUsers = MOCK_ALL_USERS.filter(u => u.state === currentUser.state);
        break;
      case 'all':
      default:
        filteredUsers = [...MOCK_ALL_USERS];
        break;
    }

    // Sort by Sikka, add rank, and filter out the current user to avoid showing them twice in the list
    return filteredUsers
      .filter(u => !(u.name === currentUser.name && u.district === currentUser.district && u.state === currentUser.state))
      .sort((a, b) => b.sikka - a.sikka)
      .map((user, index) => ({
        ...user,
        rank: index + 1,
      }));
  }, [filter, currentUser]);
  
  const currentUserRank = useMemo(() => {
    let userPool: MockUser[];
     switch(filter) {
        case 'district':
            userPool = MOCK_ALL_USERS.filter(u => u.district === currentUser.district);
            break;
        case 'state':
            userPool = MOCK_ALL_USERS.filter(u => u.state === currentUser.state);
            break;
        case 'all':
        default:
            userPool = [...MOCK_ALL_USERS];
            break;
    }
    // Find how many people have more Sikka than the current user
    const higherRankedUsers = userPool.filter(u => u.sikka > currentUserSikka).length;
    return higherRankedUsers + 1;
  }, [filter, currentUser, currentUserSikka]);


  const getFilterButtonStyle = (buttonFilter: FilterType) => {
      return filter === buttonFilter 
        ? 'bg-amber-500 text-black'
        : 'bg-gray-700 text-white';
  };

  return (
    <div className="h-full bg-gray-900 text-white flex flex-col">
      <div className="p-4">
        <h1 className="text-2xl font-bold text-amber-400 text-center mb-4">लीडरबोर्ड</h1>
        <div className="grid grid-cols-3 gap-2 bg-gray-800 p-1 rounded-full mb-4">
            <button onClick={() => setFilter('district')} className={`py-2 rounded-full font-semibold ${getFilterButtonStyle('district')}`}>आपके जिले में</button>
            <button onClick={() => setFilter('state')} className={`py-2 rounded-full font-semibold ${getFilterButtonStyle('state')}`}>आपके राज्य में</button>
            <button onClick={() => setFilter('all')} className={`py-2 rounded-full font-semibold ${getFilterButtonStyle('all')}`}>पूरे भारत में</button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto px-4">
        <div className="space-y-2">
            {leaderboardData.map((entry) => (
              <div key={`${entry.rank}-${entry.name}`} className="flex items-center p-3 rounded-lg bg-gray-800">
                <span className="text-xl font-bold w-10">{entry.rank}</span>
                <div className="flex-1">
                  <p className="font-semibold">{entry.name}</p>
                  <p className="text-xs text-gray-400">{`${entry.district}, ${entry.state}`}</p>
                </div>
                <div className="text-right">
                    <p className="font-bold text-amber-400 text-lg">{entry.sikka.toLocaleString('en-IN')}</p>
                    <p className="text-xs text-gray-400">सिक्का</p>
                </div>
              </div>
            ))}
        </div>
      </div>

      <div className="p-4 border-t border-gray-700 bg-gray-800">
         <div className="flex items-center p-3 rounded-lg bg-green-800 border border-green-500">
            <span className="text-xl font-bold w-10 text-green-300">{currentUserRank}</span>
            <div className="flex-1">
                <p className="font-semibold">{currentUser.name} (आप)</p>
                <p className="text-xs text-gray-300">{`${currentUser.district}, ${currentUser.state}`}</p>
            </div>
            <div className="text-right">
                <p className="font-bold text-green-300 text-lg">{currentUserSikka.toLocaleString('en-IN')}</p>
                <p className="text-xs text-gray-300">सिक्का</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default RankScreen;

import React, { useState } from 'react';
import { Reward, ClaimedReward } from '../types';
import { CoinIcon } from '../components/icons/Icons';

interface RewardsScreenProps {
  sikkaBalance: number;
  rewards: Reward[];
  onClaim: (reward: Reward) => boolean;
  claimedRewards: ClaimedReward[];
}

const RewardsScreen: React.FC<RewardsScreenProps> = ({ sikkaBalance, rewards, onClaim, claimedRewards }) => {
    const [view, setView] = useState<'bazaar' | 'myRewards'>('bazaar');

    const handleClaim = (reward: Reward) => {
        if (sikkaBalance < reward.sikkaCost) {
            alert('आपके पास पर्याप्त सिक्का नहीं हैं।');
            return;
        }
        const success = onClaim(reward);
        if (success) {
            alert(`बधाई हो! आपने "${reward.name}" प्राप्त कर लिया है।`);
        } else {
            alert('कुछ गड़बड़ हुई। कृपया फिर प्रयास करें।');
        }
    };
    
    const getTabStyle = (tabName: 'bazaar' | 'myRewards') => {
        return view === tabName
            ? 'border-amber-400 text-amber-400'
            : 'border-transparent text-gray-400';
    };

  return (
    <div className="h-full bg-gray-900 text-white flex flex-col">
      <div className="p-4">
        <h1 className="text-2xl font-bold text-amber-400">बाज़ार (Rewards)</h1>
        <div className="mt-4 bg-gray-800 p-4 rounded-lg flex justify-between items-center">
            <p className="text-lg">आपके सिक्के</p>
            <div className="flex items-center space-x-2">
                <CoinIcon className="h-8 w-8 text-amber-400" />
                <span className="text-2xl font-bold text-white">{sikkaBalance.toLocaleString('en-IN')}</span>
            </div>
        </div>
      </div>

        <div className="border-b border-gray-700 px-4">
            <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                <button onClick={() => setView('bazaar')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${getTabStyle('bazaar')}`}>
                    बाज़ार
                </button>
                <button onClick={() => setView('myRewards')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${getTabStyle('myRewards')}`}>
                    मेरे इनाम
                </button>
            </nav>
        </div>

      <div className="flex-1 overflow-y-auto p-4">
        {view === 'bazaar' ? (
            <div className="grid grid-cols-2 gap-4">
                {rewards.map(reward => (
                <div key={reward.id} className="bg-gray-800 rounded-lg p-3 flex flex-col justify-between shadow-lg">
                    <div>
                        <img src={reward.imageUrl} alt={reward.name} className="w-full h-24 object-cover rounded-md mb-2"/>
                        <h3 className="font-bold text-md">{reward.name}</h3>
                        <p className="text-xs text-gray-400 mb-2">{reward.description}</p>
                    </div>
                    <button 
                        onClick={() => handleClaim(reward)}
                        className="w-full mt-2 bg-amber-500 hover:bg-amber-600 disabled:bg-gray-600 text-black font-bold py-2 px-2 rounded-full text-sm"
                        disabled={sikkaBalance < reward.sikkaCost}
                    >
                        {reward.sikkaCost.toLocaleString('en-IN')} सिक्का + ₹{reward.iapCost}
                    </button>
                </div>
                ))}
            </div>
        ) : (
             <div className="space-y-4">
                {claimedRewards.length === 0 ? (
                    <p className="text-center text-gray-400 mt-8">आपने अभी तक कोई इनाम नहीं जीता है।</p>
                ) : (
                    claimedRewards.map((reward, index) => (
                        <div key={index} className="bg-gray-800 rounded-lg p-3 flex items-center space-x-4">
                            <img src={reward.imageUrl} alt={reward.name} className="w-16 h-16 object-cover rounded-md"/>
                            <div>
                                <h3 className="font-bold text-md">{reward.name}</h3>
                                <p className="text-xs text-green-400">प्राप्त किया</p>
                                <p className="text-xs text-gray-400">{reward.claimDate.toLocaleDateString('hi-IN')}</p>
                            </div>
                        </div>
                    ))
                )}
            </div>
        )}
      </div>
    </div>
  );
};

export default RewardsScreen;


import React, { useState } from 'react';
import { MOCK_QUIZZES } from '../constants';
import { Quiz, Question } from '../types';
import { ArrowLeftIcon } from '../components/icons/Icons';

interface QuizScreenProps {
  onQuizComplete: (score: number) => void;
}

const QuizScreen: React.FC<QuizScreenProps> = ({ onQuizComplete }) => {
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);

  const currentQuestion: Question | undefined = activeQuiz?.questions[currentQuestionIndex];

  const handleAnswer = (answerIndex: number) => {
    if (isAnswered) return;
    
    setSelectedAnswer(answerIndex);
    setIsAnswered(true);

    if (answerIndex === currentQuestion?.correctAnswerIndex) {
      setScore(prev => prev + 10);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < (activeQuiz?.questions.length ?? 0) - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      resetQuestionState();
    } else {
      // Quiz finished
      const totalScore = score + (score === activeQuiz!.questions.length * 10 ? 100 : 0); // Bonus
      onQuizComplete(totalScore);
      setActiveQuiz(null);
      resetQuestionState();
    }
  };

  const resetQuestionState = () => {
    setSelectedAnswer(null);
    setIsAnswered(false);
    if (currentQuestionIndex === (activeQuiz?.questions.length ?? 0) - 1) {
        setScore(0);
        setCurrentQuestionIndex(0);
    }
  };

  const startQuiz = (quiz: Quiz) => {
    setActiveQuiz(quiz);
    resetQuestionState();
    setScore(0);
    setCurrentQuestionIndex(0);
  };
  
  if (activeQuiz && currentQuestion) {
    const isCorrect = selectedAnswer === currentQuestion.correctAnswerIndex;
    return (
      <div className="h-full bg-gray-900 text-white p-4 flex flex-col">
        <div className="flex items-center mb-4">
           <button onClick={() => setActiveQuiz(null)} className="mr-4 text-amber-400">
             <ArrowLeftIcon className="h-6 w-6" />
           </button>
           <h1 className="text-xl font-bold text-amber-400">{activeQuiz.title}</h1>
        </div>
        <div className="flex-1 flex flex-col justify-center">
            <p className="text-gray-300 mb-2">{`प्रश्न ${currentQuestionIndex + 1}/${activeQuiz.questions.length}`}</p>
            <h2 className="text-2xl font-semibold mb-6">{currentQuestion.text}</h2>
            <div className="space-y-4">
              {currentQuestion.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswer(index)}
                  disabled={isAnswered}
                  className={`w-full text-left p-4 rounded-lg text-lg transition-colors duration-200 ${
                    isAnswered && index === currentQuestion.correctAnswerIndex ? 'bg-green-600 border-green-400' :
                    isAnswered && index === selectedAnswer && !isCorrect ? 'bg-red-600 border-red-400' :
                    'bg-gray-800 hover:bg-gray-700 border border-gray-600'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
            {isAnswered && (
                <div className="mt-6 text-center">
                    <p className={`text-xl font-bold ${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
                        {isCorrect ? 'सही जवाब!' : 'गलत जवाब!'}
                    </p>
                    <button onClick={handleNext} className="mt-4 bg-amber-500 hover:bg-amber-600 text-black font-bold py-2 px-8 rounded-full">
                        {currentQuestionIndex === activeQuiz.questions.length - 1 ? 'खत्म करें' : 'अगला'}
                    </button>
                </div>
            )}
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-gray-900 text-white p-4 overflow-y-auto">
      <h1 className="text-2xl font-bold text-amber-400 mb-4">खेल (Quiz)</h1>
      <div className="space-y-4">
        {MOCK_QUIZZES.map(quiz => (
          <div key={quiz.id} className="bg-gray-800 p-4 rounded-lg flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold">{quiz.title}</h2>
              <p className="text-sm text-gray-400">{quiz.topic}</p>
            </div>
            <button onClick={() => startQuiz(quiz)} className="bg-amber-500 hover:bg-amber-600 text-black font-bold py-2 px-6 rounded-full">
              खेलें
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QuizScreen;

import React, { useState, useEffect, useRef } from 'react';
import { Video } from '../types';
import VideoPlayer from '../components/VideoPlayer';
import StreakIndicator from '../components/StreakIndicator';

interface HomeScreenProps {
  videos: Video[];
  onLike: (videoId: number) => void;
  onWatch: (videoId: number) => void;
  onShare: (videoId: number) => void;
  likedVideos: Set<number>;
  downloadedVideoIds: Set<number>;
  streakCount: number;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ videos, onLike, onWatch, onShare, likedVideos, downloadedVideoIds, streakCount }) => {
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const index = Number(entry.target.getAttribute('data-index'));
            setCurrentVideoIndex(index);
          }
        });
      },
      { threshold: 0.5 }
    );

    const videoElements = containerRef.current?.querySelectorAll('.video-container');
    videoElements?.forEach(el => observer.observe(el));

    return () => {
      videoElements?.forEach(el => observer.unobserve(el));
    };
  }, [videos]);

  return (
    <div className="relative h-full w-full">
      <div ref={containerRef} className="h-full w-full overflow-y-auto snap-y snap-mandatory no-scrollbar">
        {videos.map((video, index) => (
          <div key={video.id} data-index={index} className="h-full w-full snap-start video-container">
            <VideoPlayer
              video={video}
              onLike={onLike}
              onWatch={onWatch}
              onShare={onShare}
              isLiked={likedVideos.has(video.id)}
              isActive={index === currentVideoIndex}
              isDownloaded={downloadedVideoIds.has(video.id)}
            />
          </div>
        ))}
      </div>
      <StreakIndicator streak={streakCount} />
    </div>
  );
};

export default HomeScreen;